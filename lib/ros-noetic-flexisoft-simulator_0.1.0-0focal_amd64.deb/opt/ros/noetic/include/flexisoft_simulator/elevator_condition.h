#ifndef _FLEXISOFT_SIMULATOR_ELEVATOR_CONDITION_H_
#define _FLEXISOFT_SIMULATOR_ELEVATOR_CONDITION_H_

#include <flexisoft_simulator/condition.h>
#include <robotnik_msgs/ElevatorStatus.h>

class ElevatorCondition : public Condition
{
public:
  ElevatorCondition(ros::NodeHandle nh, ros::NodeHandle pnh, std::string case_name, std::string type);

  virtual ~ElevatorCondition();

  void setElevatorValues(const robotnik_msgs::ElevatorStatus::ConstPtr& msg);

  void setState(std::string state, std::string position);

  void update();

  bool isActive();

  bool isValid();

  bool receivingData();

private:
  float watchdog_;

  ros::Subscriber elevator_status_sub_;
  robotnik_msgs::ElevatorStatus elevator_status_msg_;

  std::string position_;
  std::string state_;
  bool moving_;  // specifies if this condition is active when the elevator is moving
  bool up_;      // specifies if this condition is active when the elevator is in the upper position
  bool down_;    // specifies if this condition is active when the elevator is in the lower position
};

#endif  // _FLEXISOFT_SIMULATOR_ELEVATOR_CONDITION_H_
