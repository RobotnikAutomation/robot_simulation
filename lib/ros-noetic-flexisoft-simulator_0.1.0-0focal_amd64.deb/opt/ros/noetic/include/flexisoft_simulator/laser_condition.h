#ifndef _FLEXISOFT_SIMULATOR_LASER_CONDITION_V2_H_
#define _FLEXISOFT_SIMULATOR_LASER_CONDITION_V2_H_

#include <flexisoft_simulator/condition.h>
#include <costmap_2d/footprint.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Point.h>
#include <visualization_msgs/Marker.h>

class LaserCondition : public Condition
{
public:
  LaserCondition(ros::NodeHandle nh, ros::NodeHandle pnh, std::string case_name, std::string laser_name,
                 std::string type);

  virtual ~LaserCondition();

  void setLaserValues(const sensor_msgs::LaserScan::ConstPtr& msg);

  void generateFieldOfRays();

  void update();

  bool isActive();

  bool isValid();

  bool receivingData();

  void lineDefinition(float x0, float x1, float y0, float y1);

  void intersection(geometry_msgs::Point point1, geometry_msgs::Point point2, float theta);

  std::vector<float> createLaserRays();

  float radius(float x, float y);

  float angle(float x, float y);

  std::vector<float> cartesianToPolar(geometry_msgs::Point point);

  void publishMarkers(std::vector<geometry_msgs::Point> rotated_points);
  visualization_msgs::Marker getMarkers();

  geometry_msgs::Point rotateFootprint(geometry_msgs::Point point);

  virtual std::string getName();

private:
  ros::Time last_detection_;
  float watchdog_;

  std::string laser_name_;
  std::string frame_;

  ros::Subscriber laser_sub_;
  ros::Publisher marker_pub_;
  ros::Publisher shared_marker_pub_;  // Marker publisher to publish in case is detecting obstacles

  bool subscribed_once_;
  bool read_laser_properties_;

  int samples_;

  sensor_msgs::LaserScan laser_msg_;
  geometry_msgs::Point marker_;
  visualization_msgs::Marker visual_footprint_;

  std::vector<float> rays_field_;
  std::vector<float> zone;
  std::vector<float> ranges_;

  float detection_watchdog_;
  float intersection_x_, intersection_y_;
  float slope_, ordinate_;  // Line properties: y= slope*x + ordinate; (y=mx+n)

  std::string topic_name_;                            //  name of the laser topic
  std::vector<geometry_msgs::Point> points_;          //  2D points of the safety zone
  std::vector<geometry_msgs::Point> rotated_points_;  //  2D points of the safety zone
};

#endif  // _FLEXISOFT_SIMULATOR_LASER_CONDITION_V2_H_
