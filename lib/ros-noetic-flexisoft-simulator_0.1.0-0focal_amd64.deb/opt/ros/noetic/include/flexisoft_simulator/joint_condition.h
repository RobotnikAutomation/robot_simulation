#ifndef _FLEXISOFT_SIMULATOR_JOINT_CONDITION_H_
#define _FLEXISOFT_SIMULATOR_JOINT_CONDITION_H_

#include <flexisoft_simulator/condition.h>
#include <sensor_msgs/JointState.h>
#include <XmlRpcException.h>

class JointCondition : public Condition
{
public:
  JointCondition(ros::NodeHandle nh, ros::NodeHandle pnh, std::string case_name, std::string joint_name,
                 std::string type);

  virtual ~JointCondition();

  void setJointValues(const sensor_msgs::JointState::ConstPtr& msg);

  void setPosition(float position);

  void setSpeed(float speed);

  void update();

  bool isActive();

  bool isValid();

  bool receivingData();

private:
  std::string joint_name_;

  float watchdog_;

  float position_;
  float min_position_, max_position_;
  bool has_position_limit_;
  float speed_;
  float min_speed_, max_speed_;
  bool has_speed_limit_;

  ros::Subscriber joint_states_sub_;
  sensor_msgs::JointState joint_states_msg_;

  std::vector<bool> check_param_read = { 0, 0, 0, 0, 0, 0 };
};

#endif  // _FLEXISOFT_SIMULATOR_JOINT_CONDITION_H_
