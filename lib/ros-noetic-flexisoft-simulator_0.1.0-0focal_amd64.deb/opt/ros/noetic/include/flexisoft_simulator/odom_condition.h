#ifndef _FLEXISOFT_SIMULATOR_ODOM_CONDITION_H_
#define _FLEXISOFT_SIMULATOR_ODOM_CONDITION_H_

#include <flexisoft_simulator/condition.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/Vector3.h>
#include <XmlRpcException.h>

class OdomCondition : public Condition
{
public:
  OdomCondition(ros::NodeHandle nh, ros::NodeHandle pnh, std::string case_name, std::string type);

  virtual ~OdomCondition();

  void odomCallback(const nav_msgs::Odometry::ConstPtr& msg);

  void update();

  bool isActive();

  bool isValid();

  bool receivingData();

private:
  float watchdog_;

  double min_linear_speed_;
  double max_linear_speed_;
  double min_angular_speed_;
  double max_angular_speed_;

  ros::Subscriber odom_sub_;
  nav_msgs::Odometry odom_msg_;

  //  std::vector<bool> check_param_read = { 0, 0, 0, 0, 0, 0 };
};

#endif  // _FLEXISOFT_SIMULATOR_ODOM_CONDITION_H_
