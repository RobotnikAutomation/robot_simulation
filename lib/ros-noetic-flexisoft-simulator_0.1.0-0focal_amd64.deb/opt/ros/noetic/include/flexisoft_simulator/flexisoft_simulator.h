#ifndef _FLEXISOFT_SIMULATOR_FLEXISOFT_SIMULATOR_H_
#define _FLEXISOFT_SIMULATOR_FLEXISOFT_SIMULATOR_H_

#include <memory>

#include <ros/ros.h>
#include <rcomponent/rcomponent.h>
#include <robotnik_msgs/SafetyModuleStatus.h>
#include <robotnik_msgs/LaserStatus.h>
#include <robotnik_msgs/SetLaserMode.h>

#include <flexisoft_simulator/condition.h>
#include <flexisoft_simulator/case.h>
class FlexisoftSimulator : public rcomponent::RComponent
{
public:
  FlexisoftSimulator(ros::NodeHandle h);
  virtual ~FlexisoftSimulator();

protected:
  /* RComponent stuff */

  virtual int setup();
  //! Setups all the ROS' stuff
  virtual int rosSetup();
  //! Shutdowns all the ROS' stuff
  virtual int rosShutdown();
  //! Reads data a publish several info into different topics
  virtual void rosPublish();
  //! Reads params from params server
  virtual void rosReadParams();
  //! Actions performed on init state
  virtual void initState();
  //! Actions performed on standby state
  virtual void standbyState();
  //! Actions performed on ready state
  virtual void readyState();
  //! Actions performed on the emergency state
  virtual void emergencyState();
  //! Actions performed on Failure state
  virtual void failureState();

  bool checkTopicsHealth();
  bool setLaserModeServiceCb(robotnik_msgs::SetLaserMode::Request& request,
                             robotnik_msgs::SetLaserMode::Response& response);
  bool setSafetyModeServiceCb(robotnik_msgs::SetLaserMode::Request& request,
                              robotnik_msgs::SetLaserMode::Response& response);
  bool switchToLaserMode(std::string new_laser_mode);
  bool switchToSafetyMode(std::string new_safety_mode);

public:
protected:
  /* ROS stuff */
  bool first_time;
  std::string last_case;

  std::map<std::string, std::vector<std::shared_ptr<Case>>> laser_modes_;
  std::map<std::string, std::shared_ptr<Case>> cases_;
  // std::vector<std::shared_ptr<Case>> cases_;
  std::vector<std::string> cases_names_;
  ros::Publisher flexisoft_state_;
  ros::Publisher safety_status_;
  ros::ServiceServer set_laser_mode_service_server_;
  ros::ServiceServer set_safety_mode_service_server_;

  ros::Time last_active_;
  ros::Time last_no_active_;
  float safety_timeout_;

  std::string safety_mode_;         // See robotnik_msgs::SafetyModuleStatus
  std::string laser_mode_;          // Laser modes
  std::string default_laser_mode_;  // Default laser mode
};

#endif  // _FLEXISOFT_SIMULATOR_FLEXISOFT_SIMULATOR_H_
