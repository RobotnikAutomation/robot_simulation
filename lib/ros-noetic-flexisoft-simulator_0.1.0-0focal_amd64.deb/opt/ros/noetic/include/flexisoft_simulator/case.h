#ifndef _FLEXISOFT_SIMULATOR_CASE_H_
#define _FLEXISOFT_SIMULATOR_CASE_H_

#include <memory>
#include <ros/ros.h>

#include <flexisoft_simulator/condition.h>
#include <flexisoft_simulator/all_conditions.h>
#include <XmlRpcException.h>
#include <tuple>

typedef std::vector<std::tuple<std::string, bool>> condition_active_vector;

class Case
{
public:
  Case(ros::NodeHandle nh, ros::NodeHandle pnh, std::string name);

  virtual ~Case();

  void update();

  bool isActive();

  bool isValid();

  bool receivingData();

  std::string getName();

  condition_active_vector getActiveLasers();

protected:
  bool active_;  // true if case is between safe values
  bool valid_;   // true if value of case is still valid (e.g. not timedout)
  bool received_;
  std::vector<std::shared_ptr<Condition>> conditions_;

  std::string name_;
};

#endif  // _FLEXISOFT_SIMULATOR_CASE_H_
