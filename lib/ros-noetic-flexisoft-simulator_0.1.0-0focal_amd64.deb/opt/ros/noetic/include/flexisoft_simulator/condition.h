#ifndef _FLEXISOFT_SIMULATOR_CONDITION_H_
#define _FLEXISOFT_SIMULATOR_CONDITION_H_

#include <ros/ros.h>

class Condition
{
public:
  Condition(ros::NodeHandle nh, ros::NodeHandle pnh, std::string name, std::string type);

  virtual ~Condition();

  virtual void update() = 0;

  virtual bool isActive();

  virtual bool isValid();

  virtual bool receivingData();

  virtual std::string getName();

  std::string getType();

protected:
  ros::NodeHandle nh_;   // global node handle
  ros::NodeHandle pnh_;  // private node handle
  bool received_;
  bool active_;     // true if condition is between safe values
  bool valid_;      // true if value of condition is still valid (e.g. not timedout)
  bool receiving_;  // true if the node is subscribed to the topic and the topic contains data
  ros::Time last_stamp_;

  std::string name_;
  std::string type_;
};

#endif  // _FLEXISOFT_SIMULATOR_CONDITION_H_
