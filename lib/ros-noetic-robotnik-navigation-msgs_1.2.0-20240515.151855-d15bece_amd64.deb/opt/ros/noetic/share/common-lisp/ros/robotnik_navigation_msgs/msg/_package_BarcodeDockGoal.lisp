(cl:in-package robotnik_navigation_msgs-msg)
(cl:export '(BARCODE_ID-VAL
          BARCODE_ID
          POSITION-VAL
          POSITION
))