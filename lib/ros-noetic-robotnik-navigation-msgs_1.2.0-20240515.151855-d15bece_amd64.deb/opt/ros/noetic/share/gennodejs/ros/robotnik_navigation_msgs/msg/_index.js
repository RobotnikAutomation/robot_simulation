
"use strict";

let RobotnikMoveBaseFlexResultAction = require('./RobotnikMoveBaseFlexResultAction.js');
let RobotnikMoveBaseFlexGoalAction = require('./RobotnikMoveBaseFlexGoalAction.js');
let PoseStampedArray = require('./PoseStampedArray.js');
let RobotnikMoveBaseFlexFeedbackAction = require('./RobotnikMoveBaseFlexFeedbackAction.js');
let BarcodeDockActionGoal = require('./BarcodeDockActionGoal.js');
let RobotnikMoveBaseFlexActionFeedback = require('./RobotnikMoveBaseFlexActionFeedback.js');
let BarcodeDockResult = require('./BarcodeDockResult.js');
let DockActionGoal = require('./DockActionGoal.js');
let DockActionResult = require('./DockActionResult.js');
let RobotnikMoveBaseFlexResult = require('./RobotnikMoveBaseFlexResult.js');
let MoveResult = require('./MoveResult.js');
let DockAction = require('./DockAction.js');
let BarcodeDockActionFeedback = require('./BarcodeDockActionFeedback.js');
let RobotnikMoveBaseFlexActionGoal = require('./RobotnikMoveBaseFlexActionGoal.js');
let BarcodeDockActionResult = require('./BarcodeDockActionResult.js');
let BarcodeDockFeedback = require('./BarcodeDockFeedback.js');
let RobotnikMoveBaseFlexFeedback = require('./RobotnikMoveBaseFlexFeedback.js');
let RobotnikMoveBaseFlexActionResult = require('./RobotnikMoveBaseFlexActionResult.js');
let BarcodeDockGoal = require('./BarcodeDockGoal.js');
let DockFeedback = require('./DockFeedback.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let DockGoal = require('./DockGoal.js');
let RobotnikMoveBaseFlexGoal = require('./RobotnikMoveBaseFlexGoal.js');
let MoveAction = require('./MoveAction.js');
let RobotnikMoveBaseFlexAction = require('./RobotnikMoveBaseFlexAction.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let DockActionFeedback = require('./DockActionFeedback.js');
let DockResult = require('./DockResult.js');
let MoveFeedback = require('./MoveFeedback.js');
let BarcodeDockAction = require('./BarcodeDockAction.js');
let MoveGoal = require('./MoveGoal.js');
let MoveActionResult = require('./MoveActionResult.js');

module.exports = {
  RobotnikMoveBaseFlexResultAction: RobotnikMoveBaseFlexResultAction,
  RobotnikMoveBaseFlexGoalAction: RobotnikMoveBaseFlexGoalAction,
  PoseStampedArray: PoseStampedArray,
  RobotnikMoveBaseFlexFeedbackAction: RobotnikMoveBaseFlexFeedbackAction,
  BarcodeDockActionGoal: BarcodeDockActionGoal,
  RobotnikMoveBaseFlexActionFeedback: RobotnikMoveBaseFlexActionFeedback,
  BarcodeDockResult: BarcodeDockResult,
  DockActionGoal: DockActionGoal,
  DockActionResult: DockActionResult,
  RobotnikMoveBaseFlexResult: RobotnikMoveBaseFlexResult,
  MoveResult: MoveResult,
  DockAction: DockAction,
  BarcodeDockActionFeedback: BarcodeDockActionFeedback,
  RobotnikMoveBaseFlexActionGoal: RobotnikMoveBaseFlexActionGoal,
  BarcodeDockActionResult: BarcodeDockActionResult,
  BarcodeDockFeedback: BarcodeDockFeedback,
  RobotnikMoveBaseFlexFeedback: RobotnikMoveBaseFlexFeedback,
  RobotnikMoveBaseFlexActionResult: RobotnikMoveBaseFlexActionResult,
  BarcodeDockGoal: BarcodeDockGoal,
  DockFeedback: DockFeedback,
  MoveActionFeedback: MoveActionFeedback,
  DockGoal: DockGoal,
  RobotnikMoveBaseFlexGoal: RobotnikMoveBaseFlexGoal,
  MoveAction: MoveAction,
  RobotnikMoveBaseFlexAction: RobotnikMoveBaseFlexAction,
  MoveActionGoal: MoveActionGoal,
  DockActionFeedback: DockActionFeedback,
  DockResult: DockResult,
  MoveFeedback: MoveFeedback,
  BarcodeDockAction: BarcodeDockAction,
  MoveGoal: MoveGoal,
  MoveActionResult: MoveActionResult,
};
