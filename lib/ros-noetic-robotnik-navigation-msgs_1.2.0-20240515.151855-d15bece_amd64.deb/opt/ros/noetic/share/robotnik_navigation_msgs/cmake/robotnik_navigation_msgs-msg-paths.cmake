# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${robotnik_navigation_msgs_DIR}/.." "msg;msg;msg;msg;msg" robotnik_navigation_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(robotnik_navigation_msgs_MSG_DEPENDENCIES actionlib_msgs;geometry_msgs;std_msgs)
